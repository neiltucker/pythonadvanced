# Make sure environment varaible set for FLASK_APP (e.g., set FLASK_APP=app.py or $env:FLASK_APP = "app.py")
# Import the Flask class from the flask module
from flask import Flask, render_template 
import pandas as pd

# Create a new Flask app
app = Flask(__name__)

# Define a route for the default URL
@app.route("/")
def home_page():
    return render_template('index.html')

@app.route("/home")
def home():
    return "<p>Hello, Flask!</p>  <p>Welcome home!</p>"

@app.route("/aboutme")
def aboutme():
    return "About Me!"

@app.route('/csvdata')
def csvdata():
    data = pd.read_csv('orderdata.csv')
    header = "<html><title>Flask App</title><h1>Orders Table:</h1><body>"
    footer = "</body></html>"
    return header + data.to_html(index=False, index_names=False) + footer

@app.route('/htmldata')
def htmldata():
    return render_template('orderdata.html')

# Run the app if it is the main module
if __name__ == '__main__':
    app.run()
